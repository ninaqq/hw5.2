#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int die_cnt[11] = { 0 };
	int die_cnt2[6][6] = { 0 };
	int die1, die2;

	srand(time(NULL));

	for (int i = 0; i < 36000; i++)
	{
		die1 = rand() % 6 + 1;
		die2 = rand() % 6 + 1;

		die_cnt2[die1 - 1][die2 - 1]++;
		die_cnt[die1 + die2 - 2]++;
	}

	printf("The numbers of times each possivle sum appears :\n");

	printf(" ");
	for (int i = 1; i < 7; i++)
		printf("%10d", i);

	puts("");

	for (int i = 0; i < 6; i++)
	{
		printf("%-10d", i + 1);

		for (int j = 0; j < 6; j++)
		{
			printf("%-10d", die_cnt2[i][j]);
		}
		puts("");
	}

	puts("\n\n");

	float value;

	for (int i = 0; i < 11; i++)
	{
		value = 0;
		for (int j = 0; j < 6; j++)
		{
			for (int k = 0; k < 6; k++)
			{
				if (i == k + j)
					value++;
			}
		}
		value = value / 36 * 100;

		printf("%d Theoretical value : %.2f AND Actual value : %.2f \n", i + 2, value, die_cnt[i] / 360.0);
	}
	return 0;
}